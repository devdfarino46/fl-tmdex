# GULP

Require install `Node JS` and `NPM`
Install dependencies `npm setup`
Run project `npm start`

# Gulp-file-include code snipets
